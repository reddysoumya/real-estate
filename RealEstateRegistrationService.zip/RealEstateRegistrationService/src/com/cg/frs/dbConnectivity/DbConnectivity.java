package com.cg.frs.dbConnectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class DbConnectivity {
	private static Connection conn = null;
	//static factory 
		public static Connection getDbConnection() {
			PropertyConfigurator.configure("resources/log4j.properties");
			Logger log=Logger.getRootLogger();
			String url="jdbc:oracle:thin:@10.219.34.3:1521/orcl";
			String user="trg212";
			String pass="training212";
			try {
				conn = DriverManager.getConnection(url, user, pass);
				log.info("connection successfully established");
				//Connection has been successfully established

			} catch (SQLException e) {
				log.error("connection problem :: "+e.getMessage());
				System.out.println("connection problem :: " + e.getMessage());
			}
			return conn;
		}


}
