package com.cg.frs.dtoBean;

public class FlatOwnersBean {
	private int ownerId;

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	

}
