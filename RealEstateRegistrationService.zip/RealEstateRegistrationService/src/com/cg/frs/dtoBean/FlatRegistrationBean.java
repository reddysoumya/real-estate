package com.cg.frs.dtoBean;

public class FlatRegistrationBean {
	private int flatRegNo;
	private int ownerId;
	private int flatType;
	private int flatArea;
	private double rentAmount;
	private double depositAmount;
	public int getFlatRegNo() {
		return flatRegNo;
	}
	public void setFlatRegNo(int flatRegNo) {
		this.flatRegNo = flatRegNo;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public int getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	public double getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}
	
	
	
	public FlatRegistrationBean() {
		super();
		
	}
	
	
	
	public FlatRegistrationBean(int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount) {
		super();
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}
	
	
	
	public FlatRegistrationBean(int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount,
			double depositAmount) {
		super();
		this.flatRegNo = flatRegNo;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}
	
	
	@Override
	public String toString() {
		return "FlatRegistrationBean [flatRegNo=" + flatRegNo + ", ownerId=" + ownerId + ", flatType=" + flatType
				+ ", flatArea=" + flatArea + ", rentAmount=" + rentAmount + ", depositAmount=" + depositAmount + "]";
	}
	
	

}
