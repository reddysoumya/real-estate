package com.cg.frs.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dtoBean.FlatOwnersBean;
import com.cg.frs.dtoBean.FlatRegistrationBean;
import com.cg.frs.exception.UserDefinedFlatException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;


public class FlatRegistrationClient {
	static Scanner scan=null;
	static IFlatRegistrationService flatServ=null;
	static FlatRegistrationBean flat=null;
	static FlatOwnersBean flatBean=null;
	
	
	public static void main(String[] args) throws UserDefinedFlatException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		FlatRegistrationClient frc=new FlatRegistrationClient();
		
		
		System.out.println("===Real Estate Registration Service===");
		System.out.println("--------------------------------");
		System.out.println("1. Register Flat");
		System.out.println("2. Exit");
		System.out.println("--------------------------------");
		
		scan=new Scanner(System.in);
		int option=scan.nextInt();
		
		switch(option){
		
		
		case 1:
			log.info("entered the case "+option );
			flatServ = new FlatRegistrationServiceImpl();
			
			// int ownerId=frc.getOwnerId(flatBean);
			// flat.setOwnerId(ownerId);
			 
			 
			 
		
			int ownerId=	flatServ.validateOwnerId();
			//int ownerId1=frc.getOwnerId(flatBean);
			/*if(ownerId!=ownerId1)
			{
				System.out.println("Owner does not exists in the database");
				log.info("Owner does not exists in the database");
				System.exit(0);
			}*/
			int flatType=	flatServ.validateFlatType();
			int flatArea=	flatServ.validateFlatArea();
			
			double rentAmount=	flatServ.validateRentAmount();
			
			double depositAmount=	flatServ.validateDepositAmount();

			 
			
	
			 flat=new FlatRegistrationBean(ownerId, flatType, flatArea, rentAmount, depositAmount);
			 
			int flatRegNo = 0;
			 
			flatRegNo = registerFlat(flat);
			log.info("Registration is successfully done");
			 
			if(flatRegNo > 0) {
				log.info(flat +" are the details that are stored");
			System.out.println("Flat successfully registered."+"Registration Id is: "+flatRegNo);

			}
			 
			else {
			 log.info("details are not stored");
			System.out.println("Details Not Inserted!!!!!!");

			}
			 
			break;
		case 2:
			System.out.println("exiting the registration application");
			System.exit(0);
			break;
		default:System.out.println("Please enter valid choice");
			break;

		}
}

	private static int registerFlat(FlatRegistrationBean flat2) throws UserDefinedFlatException {
		flatServ=new FlatRegistrationServiceImpl();
		int result=flatServ.storeFlatRegister(flat2);
		return result;
	}
	
	private int getOwnerId(FlatOwnersBean flatBean2) throws UserDefinedFlatException
	{
		flatServ=new FlatRegistrationServiceImpl();
		int result=flatServ.storeFlatOwnerId(flatBean2);
		return result;
	}
}
