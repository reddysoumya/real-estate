package com.cg.frs.test;

import java.sql.Connection;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.frs.dao.FlatRegistrationDaoImpl;
import com.cg.frs.dbConnectivity.DbConnectivity;
import com.cg.frs.dtoBean.FlatRegistrationBean;
import com.cg.frs.exception.UserDefinedFlatException;

import junit.framework.Assert;

public class FlatRegistrationTestCases {
	DbConnectivity dbc=null;
	Connection conn=null;
	
	FlatRegistrationDaoImpl frdi=null;
	FlatRegistrationBean flat=null;
	
	@Before
	public void init()
	{
		 conn=DbConnectivity.getDbConnection();
	}
	@Test
	public void checkDbConnectivity()
	{
		
		Assert.assertNotNull(conn);
	}
	
	@After
	public void destroy()
	{
		conn=null;
	}
	@Before
	public void init1()
	{
		 frdi=new FlatRegistrationDaoImpl();
		 flat=new FlatRegistrationBean(1,1,650,7000,25000);
	}
	@Test
	public void checkStoreFlatRegister() throws UserDefinedFlatException
	{
		int returnId=frdi.storeFlatRegister(flat);
		Assert.assertEquals(1003, returnId);
	}
	
	@After
	public void destroy1()
	{
		frdi=null;
	}

}
