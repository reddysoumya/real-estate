package com.cg.frs.exception;

public class UserDefinedFlatException extends Exception {
	public UserDefinedFlatException() {
		
	}
	public UserDefinedFlatException(String msg) {
		super(msg);
	}

}
