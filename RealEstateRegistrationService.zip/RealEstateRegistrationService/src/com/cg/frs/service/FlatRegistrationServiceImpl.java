package com.cg.frs.service;

import java.util.Scanner;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.frs.dao.FlatRegistrationDaoImpl;
import com.cg.frs.dao.IFlatRegistrationDao;
import com.cg.frs.dtoBean.FlatOwnersBean;
import com.cg.frs.dtoBean.FlatRegistrationBean;
import com.cg.frs.exception.UserDefinedFlatException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	IFlatRegistrationDao fdao=null;
	static Scanner scan=new Scanner(System.in);
	
	@Override
	public int validateOwnerId() {
		int ownerId = 0;
		do
		{
		System.out.println("Existing Owners IDS Are:-[1, 2, 3]");
		System.out.println("Please enter your owner id from above list:");
		ownerId=scan.nextInt();
		if(ownerId<1&&ownerId>3)
		{
			System.out.println("Please enter the owner Id in the range ");
		}
			
		
		}while(ownerId<1&&ownerId>3);
	return ownerId;
	}

	@Override
	public int validateFlatType() {
		int flatType = 0;
		do
		{
		System.out.println("Select the Flat Type(1-1BHK,2-2BHK)");
		flatType=scan.nextInt();
		if(flatType!=1&&flatType!=2)
		{
			System.out.println("Please enter the Flat Type in the range ");
		}
			
		
		}while(flatType!=1&&flatType!=2);
	return flatType;
	}

	@Override
	public int validateFlatArea() {
		int flatArea = 0;
		 
		do {
	 
			System.out.println("Enter Flat Area: ");
	 
			flatArea = scan.nextInt();
			
			if(flatArea<0&&flatArea>2000) {
	 
				System.out.println("Enter Flat Area less than 2000 sq.ft..");

			}
	 
		}while(flatArea<0&&flatArea>2000);
	 
	return flatArea;
	}

	@Override
	public double validateRentAmount() {
		double rentAmount = 0;
		 
		do {
	 
			System.out.println("Enter Rent Amount: ");
	 
			rentAmount = scan.nextDouble();
			
			if(rentAmount<6000||rentAmount>10000) {
	 
				System.out.println("Enter Rent Amount greater than 6000 and less than 10000");

			}
	 
		}while(rentAmount<6000||rentAmount>10000);
	 
	return rentAmount;
	}

	@Override
	public double validateDepositAmount() {
		double depositAmount = 0;
		 
		do {
	 
			System.out.println("Enter Deposit Amount: ");
	 
			depositAmount = scan.nextDouble();
			
			if(depositAmount<10000||depositAmount>50000) {
	 
				System.out.println("Enter Rent Amount greater than 10000 and less than 50000");

			}
	 
		}while(depositAmount<10000||depositAmount>50000);
	 
	return depositAmount;
	}



	@Override
	public int storeFlatRegister(FlatRegistrationBean flat2) throws UserDefinedFlatException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log;
		log = Logger.getRootLogger();
		int retId=0;
		try {
			
			fdao=new FlatRegistrationDaoImpl();
			retId=fdao.storeFlatRegister(flat2);
			log.info("data is successfully recieved from user and passed through DAO layer"+retId);
		} catch (Exception e) {
			log.error("data is not successfully recieved"+e.getMessage());
		}
		
		
		return retId;
	}

	@Override
	public int storeFlatOwnerId(FlatOwnersBean flatBean2) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log;
		log = Logger.getRootLogger();
		int ownerId=0;
		try {
			
			fdao=new FlatRegistrationDaoImpl();
			ownerId=fdao.getOwnerId(flatBean2);
			log.info("data is successfully recieved from user and passed through DAO layer"+ownerId);
		} catch (Exception e) {
			log.error("data is not successfully recieved"+e.getMessage());
		}
		
		
		return ownerId;
		
	}


	
	

}
