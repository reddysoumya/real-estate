package com.cg.frs.service;

import com.cg.frs.dtoBean.FlatOwnersBean;
import com.cg.frs.dtoBean.FlatRegistrationBean;
import com.cg.frs.exception.UserDefinedFlatException;

public interface IFlatRegistrationService {
	public abstract int validateFlatArea();
	public abstract double validateRentAmount();
	public abstract double validateDepositAmount();
	public abstract int storeFlatRegister(FlatRegistrationBean flat2) throws UserDefinedFlatException;
	public abstract int storeFlatOwnerId(FlatOwnersBean flatBean2);
	public abstract int validateFlatType();
	public abstract int validateOwnerId();


}
