package com.cg.frs.dao;


import com.cg.frs.dtoBean.FlatOwnersBean;
import com.cg.frs.dtoBean.FlatRegistrationBean;
import com.cg.frs.exception.UserDefinedFlatException;

public interface IFlatRegistrationDao {
	public abstract int storeFlatRegister(FlatRegistrationBean flat)throws UserDefinedFlatException;

	




	






public	int getOwnerId(FlatOwnersBean flatBean2) throws UserDefinedFlatException;

}
