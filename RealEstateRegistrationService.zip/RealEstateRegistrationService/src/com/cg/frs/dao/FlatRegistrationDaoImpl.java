package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dbConnectivity.DbConnectivity;
import com.cg.frs.dtoBean.FlatOwnersBean;
import com.cg.frs.dtoBean.FlatRegistrationBean;
import com.cg.frs.exception.UserDefinedFlatException;

public class FlatRegistrationDaoImpl implements IFlatRegistrationDao {
	Connection conn=null;

	@Override
	public int storeFlatRegister(FlatRegistrationBean flat) throws UserDefinedFlatException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		int status=0, flatRegNo=0;
		conn=DbConnectivity.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.FLATREGISTER_INSERT_QRY);
			pst.setInt(1,flat.getOwnerId());
			pst.setInt(2,flat.getFlatType());
			pst.setInt(3,flat.getFlatArea());
			pst.setDouble(4,flat.getRentAmount());	
			pst.setDouble(5,flat.getDepositAmount());	
			status=pst.executeUpdate();
			log.info(status+" data is inserted");
			
			pst=conn.prepareStatement(IQueryMapper.SELECT_FLATREGISTRATION_ID);
			 ResultSet rs=pst.executeQuery();
			 if(rs.next())
			 {
				flatRegNo=rs.getInt(1);
				log.info(flatRegNo);
			 }
			
		
			
		} catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new UserDefinedFlatException("data not stored "+e.getMessage());
		}
		
		return flatRegNo;
	}

	@Override
	public int getOwnerId(FlatOwnersBean flatBean2) throws UserDefinedFlatException {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger log=Logger.getRootLogger();
		int status=0, ownerId=0;
		conn=DbConnectivity.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.FLATOWNER_SELECT_QRY);
			
			 ResultSet rs=pst.executeQuery();
			 if(rs.next())
			 {
				ownerId=rs.getInt(1);
				log.info(ownerId);
			 }
			
		
			
		} catch (SQLException e) {
			log.error("data is not stored:: "+e.getMessage());
			throw new UserDefinedFlatException("data not stored "+e.getMessage());
		}
		
		return ownerId;
	}

	

	

}
