package com.cg.frs.dao;

public interface IQueryMapper {
	public static final String FLATREGISTER_INSERT_QRY="insert into flatregistration values(flat_seq.NEXTVAL,?,?,?,?,?)";
	public static final String SELECT_FLATREGISTRATION_ID="SELECT flat_seq.CURRVAL FROM DUAL";
	public static final String FLATOWNER_SELECT_QRY="SELECT ownerid FROM flatowners";

}
